require 'test_helper'

class SmoothieIngredientsControllerTest < ActionDispatch::IntegrationTest
  # test "the truth" do
  #   assert true
  # end
end
