require 'test_helper'

class SmoothieIngredientTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
