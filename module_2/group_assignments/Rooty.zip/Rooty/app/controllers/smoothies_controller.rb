class SmoothiesController < ApplicationController
end
