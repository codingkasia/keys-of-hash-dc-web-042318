module SmoothiesHelper
end
